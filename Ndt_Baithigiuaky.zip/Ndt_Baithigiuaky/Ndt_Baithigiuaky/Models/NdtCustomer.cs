﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ndt_Baithigiuaky.Models
{
    public class NdtCustomer
    {
     public string _2210900071_CusId { get; set; }
        public string Ndt_FullName { get; set; }
        public string Ndt_Address { get; set; }
        public string Ndt_Email { get; set; }
        public string Ndt_Phone { get; set; }
        public int Ndt_Balance { get; set; }
    }
}
